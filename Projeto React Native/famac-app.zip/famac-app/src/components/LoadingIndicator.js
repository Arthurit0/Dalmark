import { SafeAreaView } from "react-native-safe-area-context";
import { ActivityIndicator } from "react-native-paper";

export function LoadingIndicator() {
  return (
    <SafeAreaView
      style={{
        justifyContent: "center",
        position: "absolute",
        top: 0,
        right: 0,
        bottom: 0,
        left: 0
      }}
    >
      <ActivityIndicator animating={true} size="large" color="#6BBE6B" />
    </SafeAreaView>
  );
}
