import { View } from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Icon from "react-native-ico";

import { Tab01 } from "../screens/Tab01";
import { Tab02 } from "../screens/Tab02";
import { TabLabel } from "../components/TabLabel";

const Tab = createBottomTabNavigator();

export function TabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        tabBarLabelPosition: "below-icon",
        tabBarStyle: {
          backgroundColor: "#FFFFFF",
          borderTopWidth: 0
        }
      }}
    >
      <Tab.Screen
        name="Tab01"
        component={Tab01}
        options={{
          tabBarIcon: ({ focused }) => {
            return (
              <View style={{ alignItems: "center" }}>
                <Icon
                  name="magnifying-glass"
                  group="universalicons"
                  color={focused ? "#6BBE6B" : "#757575"}
                />
                <TabLabel
                  focused={focused}
                  labelSize={10}
                  focusedColor="#6BBE6B"
                  unfocusedColor="#757575"
                  title="Consultar Produto"
                />
              </View>
            );
          }
        }}
      />
      <Tab.Screen
        name="Tab02"
        component={Tab02}
        options={{
          tabBarIcon: ({ focused }) => {
            return (
              <View style={{ alignItems: "center" }}>
                <Icon
                  name="helm"
                  group="miscellaneous"
                  color={focused ? "#6BBE6B" : "#757575"}
                />
                <TabLabel
                  focused={focused}
                  labelSize={10}
                  focusedColor="#6BBE6B"
                  unfocusedColor="#757575"
                  title="Assistência Técnica"
                />
              </View>
            );
          }
        }}
      />
    </Tab.Navigator>
  );
}
